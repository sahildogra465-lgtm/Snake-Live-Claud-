// Snake LIVE bridge: reads REAL YouTube LIVE data and forwards it to the app over WebSocket.
//   comments -> {"type":"comment","count":N}   (new live-chat messages)
//   likes    -> {"type":"like","count":N}      (increase of the stream's like count)
// Usage:  YT_API_KEY=xxxx YT_VIDEO_ID=yyyy node server.js
import { WebSocketServer } from 'ws';

const API_KEY = process.env.YT_API_KEY;
const VIDEO_ID = process.env.YT_VIDEO_ID;
const PORT = Number(process.env.PORT || 8080);
const CHAT_POLL_MS = Number(process.env.CHAT_POLL_MS || 10000);  // min gap between chat polls
const LIKE_POLL_MS = Number(process.env.LIKE_POLL_MS || 5000);

if (!API_KEY || !VIDEO_ID) {
  console.error('Set YT_API_KEY and YT_VIDEO_ID (see README.md).');
  process.exit(1);
}

const API = 'https://www.googleapis.com/youtube/v3';
const wss = new WebSocketServer({ port: PORT });
wss.on('connection', (ws) => console.log('App connected. Clients:', wss.clients.size));
console.log(`Bridge listening on ws://0.0.0.0:${PORT}`);

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const c of wss.clients) if (c.readyState === 1) c.send(msg);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function yt(path, params) {
  const url = `${API}/${path}?${new URLSearchParams({ ...params, key: API_KEY })}`;
  const res = await fetch(url);
  const json = await res.json();
  if (!res.ok) throw new Error(`${res.status} ${json?.error?.message || ''}`);
  return json;
}

async function getVideo() {
  const j = await yt('videos', { part: 'liveStreamingDetails,statistics', id: VIDEO_ID });
  const v = j.items?.[0];
  if (!v) throw new Error('Video not found');
  return v;
}

// ---- comments
async function chatLoop() {
  let chatId = null;
  while (!chatId) {
    try {
      chatId = (await getVideo()).liveStreamingDetails?.activeLiveChatId;
      if (!chatId) throw new Error('No active live chat yet (is the stream live?)');
    } catch (e) { console.error('chat:', e.message); await sleep(10000); }
  }
  console.log('Live chat found.');
  let pageToken = undefined;
  let first = true;                       // first page = history, ignored
  for (;;) {
    let wait = CHAT_POLL_MS;
    try {
      const j = await yt('liveChat/messages', {
        liveChatId: chatId, part: 'snippet', maxResults: '2000',
        ...(pageToken ? { pageToken } : {}),
      });
      pageToken = j.nextPageToken;
      const n = (j.items || []).filter((m) => m.snippet?.type === 'textMessageEvent').length;
      if (!first && n > 0) { broadcast({ type: 'comment', count: n }); console.log('comments +' + n); }
      first = false;
      wait = Math.max(CHAT_POLL_MS, j.pollingIntervalMillis || 0);
    } catch (e) { console.error('chat:', e.message); wait = 15000; }
    await sleep(wait);
  }
}

// ---- likes
async function likeLoop() {
  let last = null;
  for (;;) {
    try {
      const likes = Number((await getVideo()).statistics?.likeCount);
      if (Number.isFinite(likes)) {
        if (last !== null && likes > last) { broadcast({ type: 'like', count: likes - last }); console.log('likes +' + (likes - last)); }
        last = likes;
      }
    } catch (e) { console.error('likes:', e.message); }
    await sleep(LIKE_POLL_MS);
  }
}

chatLoop();
likeLoop();
