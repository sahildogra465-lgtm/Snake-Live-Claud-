package com.snakelive

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View

class GameView(context: Context) : View(context) {

    companion object {
        const val STEP_MS = 45L           // snake speed (lower = faster)
        const val LEVEL_PAUSE_MS = 800L   // pause on the full board before the next level
        private const val HEAD = 0xFF00E5FF.toInt()
        private const val TAIL = 0xFF1565C0.toInt()
        private const val RED = 0xFFE53935.toInt()
        private const val GREEN = 0xFF4CD137.toInt()
    }

    lateinit var engine: SnakeEngine
    private val loop = Handler(Looper.getMainLooper())
    private var running = false

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF14141F.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF3A3A55.toInt()
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val r = engine.step()
            invalidate()
            if (r == SnakeEngine.Result.LEVEL_COMPLETE) {
                loop.postDelayed({
                    if (!running) return@postDelayed
                    engine.advance()
                    invalidate()
                    loop.postDelayed(this, STEP_MS)
                }, LEVEL_PAUSE_MS)
            } else {
                loop.postDelayed(this, STEP_MS)
            }
        }
    }

    fun start() {
        if (running) return
        running = true
        loop.post(tick)
    }

    fun stop() {
        running = false
        loop.removeCallbacksAndMessages(null)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val s = MeasureSpec.getSize(widthSpec)
        setMeasuredDimension(s, s)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    override fun onDraw(canvas: Canvas) {
        if (!::engine.isInitialized) return
        val w = width.toFloat()
        val n = engine.n
        val cs = w / n
        canvas.drawRoundRect(0f, 0f, w, w, 16f, 16f, bg)

        // apples (red = normal, green = LIVE interaction)
        for (c in 0 until engine.cells) {
            val a = engine.apple[c]
            if (a == 0) continue
            val cx = (c % n + 0.5f) * cs
            val cy = (c / n + 0.5f) * cs
            p.color = if (a == 1) RED else GREEN
            canvas.drawCircle(cx, cy, cs * 0.36f, p)
            p.color = 0x66FFFFFF
            canvas.drawCircle(cx - cs * 0.1f, cy - cs * 0.1f, cs * 0.09f, p)
        }

        // snake
        val size = engine.body.size
        val inset = cs * 0.06f
        for (i in 0 until size) {
            val c = engine.body[i]
            val x = (c % n) * cs
            val y = (c / n) * cs
            p.color = lerp(TAIL, HEAD, if (size > 1) i / (size - 1f) else 1f)
            rect.set(x + inset, y + inset, x + cs - inset, y + cs - inset)
            canvas.drawRoundRect(rect, cs * 0.28f, cs * 0.28f, p)
        }

        // eyes
        val head = engine.body.last()
        val hx = (head % n + 0.5f) * cs
        val hy = (head / n + 0.5f) * cs
        val fx = when (engine.lastDir) { 0 -> 1f; 1 -> -1f; else -> 0f }
        val fy = when (engine.lastDir) { 2 -> 1f; 3 -> -1f; else -> 0f }
        p.color = Color.BLACK
        for (side in intArrayOf(-1, 1)) {
            val ex = hx + fx * cs * 0.15f + (-fy) * side * cs * 0.2f
            val ey = hy + fy * cs * 0.15f + fx * side * cs * 0.2f
            canvas.drawCircle(ex, ey, cs * 0.09f, p)
        }

        canvas.drawRoundRect(2f, 2f, w - 2f, w - 2f, 16f, 16f, border)
    }
}
