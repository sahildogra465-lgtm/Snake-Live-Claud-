package com.snakelive

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * WebSocket client for the YouTube LIVE bridge (see /bridge).
 * Incoming JSON:  {"type":"comment","count":1}   {"type":"like","count":3}
 * Only real messages from the bridge are forwarded; nothing is simulated.
 */
class LiveBridge(
    private val onEvent: (type: String, count: Int) -> Unit,
    private val onStatus: (connected: Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private var socket: WebSocket? = null
    private var url = ""
    private var stopped = true
    private var attempt = 0
    private var reconnecting = false

    fun start(url: String) {
        stop()
        this.url = url.trim()
        stopped = false
        attempt = 0
        connect()
    }

    fun stop() {
        stopped = true
        reconnecting = false
        main.removeCallbacksAndMessages(null)
        socket?.cancel()
        socket = null
        onStatus(false)
    }

    private fun connect() {
        if (stopped) return
        val req = try {
            Request.Builder().url(url).build()
        } catch (e: Exception) {
            onStatus(false); return
        }
        var me: WebSocket? = null
        me = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                main.post { if (!stopped && socket === webSocket) { attempt = 0; onStatus(true) } }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    val type = o.optString("type")
                    val count = o.optInt("count", 1)
                    if (type == "comment" || type == "like") main.post { if (!stopped) onEvent(type, count) }
                } catch (_: Exception) { }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = lost(webSocket)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = lost(webSocket)
        })
        socket = me
    }

    private fun lost(ws: WebSocket) {
        main.post {
            if (stopped || socket !== ws) return@post
            onStatus(false)
            if (reconnecting) return@post
            reconnecting = true
            val delay = minOf(1000L shl minOf(attempt, 4), 15000L)
            attempt++
            main.postDelayed({ reconnecting = false; connect() }, delay)
        }
    }
}
