package com.snakelive

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : Activity(), SnakeEngine.Listener {

    private lateinit var engine: SnakeEngine
    private lateinit var game: GameView
    private lateinit var levelText: TextView
    private lateinit var likesText: TextView
    private lateinit var statusText: TextView
    private lateinit var video: VideoView
    private lateinit var sfx: Sfx
    private lateinit var bridge: LiveBridge
    private lateinit var prefs: SharedPreferences
    private var music: MediaPlayer? = null
    private var likesInBlock = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("snake_live", MODE_PRIVATE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        sfx = Sfx(this)
        buildUi()

        engine = SnakeEngine(20, this)
        game.engine = engine
        likesInBlock = prefs.getInt("likes_block", 0)
        updateLikes()
        engine.startLevel(prefs.getInt("level", 1))

        bridge = LiveBridge(::onLive, ::setStatus)
        setStatus(false)

        // Background music: low volume, endless loop
        music = MediaPlayer.create(this, R.raw.music)?.apply {
            isLooping = true
            setVolume(0.12f, 0.12f)
        }
    }

    // ---------------------------------------------------------------- UI
    private fun buildUi() {
        val w = resources.displayMetrics.widthPixels
        val pad = (w * 0.03f).toInt()
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        fun tv(text: String, size: Float, color: Int = Color.WHITE, gravity: Int = Gravity.CENTER): TextView =
            TextView(this).apply {
                this.text = text
                setTextColor(color)
                typeface = Typeface.DEFAULT_BOLD
                includeFontPadding = false
                this.gravity = gravity
                maxLines = 1
                val max = w * size
                if (Build.VERSION.SDK_INT >= 26) {
                    setAutoSizeTextTypeUniformWithConfiguration(
                        (max * 0.5f).toInt(), max.toInt(), 1, TypedValue.COMPLEX_UNIT_PX
                    )
                } else {
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, max * 0.8f)
                }
            }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0A12.toInt())
            setPadding(pad, pad, pad, pad)
        }

        // TOP ROW: LEVEL | likes/comments rules | MY VIDEO
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        levelText = tv("LEVEL 0", 0.05f, Color.WHITE, Gravity.CENTER_VERTICAL or Gravity.START)
        top.addView(levelText, LinearLayout.LayoutParams(0, WRAP, 0.9f))

        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        mid.addView(tv("1 LIKE = +5 APPLES", 0.03f, 0xFFFFD54F.toInt()), LinearLayout.LayoutParams(MATCH, WRAP))
        mid.addView(tv("1 COMMENT = +1 APPLE", 0.03f, 0xFF80DEEA.toInt()), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = pad / 2 })
        top.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1.5f))

        val vw = (w * 0.32f).toInt()
        val vh = (vw * 720f / 1160f).toInt()          // same aspect ratio as the clip
        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.BLACK); setStroke(3, Color.WHITE); cornerRadius = 8f
            }
            setPadding(3, 3, 3, 3)
        }
        video = VideoView(this)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.my_clip}"))
        video.setOnPreparedListener { mp ->
            mp.isLooping = true            // endless loop
            mp.setVolume(0f, 0f)           // clip is silent; music comes from the music player
            mp.start()
        }
        video.setOnErrorListener { _, _, _ -> true }
        box.addView(video, FrameLayout.LayoutParams(MATCH, MATCH))
        top.addView(box, LinearLayout.LayoutParams(vw, vh))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // LIKES ROW
        val likesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        likesText = tv("LIKES 0/100", 0.045f, Color.WHITE, Gravity.CENTER_VERTICAL or Gravity.START)
        likesRow.addView(likesText, LinearLayout.LayoutParams(0, WRAP, 1.1f))
        likesRow.addView(tv("+50 APPLES", 0.045f, 0xFFFFD54F.toInt()), LinearLayout.LayoutParams(0, WRAP, 1f))
        statusText = tv("DISCONNECTED", 0.03f, 0xFFFF5252.toInt(), Gravity.CENTER_VERTICAL or Gravity.END)
        likesRow.addView(statusText, LinearLayout.LayoutParams(0, WRAP, 1.1f))
        root.addView(likesRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = pad })

        root.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // GAMEPLAY SQUARE
        game = GameView(this)
        val size = w - 2 * pad
        root.addView(game, LinearLayout.LayoutParams(size, size))

        // 67 = BAN
        root.addView(tv("67 = BAN", 0.07f, 0xFFFF5252.toInt()), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = pad })

        root.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1.4f))

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val i = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(pad + i.left, pad + i.top, pad + i.right, pad + i.bottom)
            ins
        }
        setContentView(root)

        // Tap the status label to set the bridge address. Long-press LEVEL to restart from level 1.
        statusText.setOnClickListener { showUrlDialog() }
        levelText.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setMessage("Restart from LEVEL 1?")
                .setPositiveButton("Restart") { _, _ ->
                    engine.startLevel(1, clearGreen = true)
                    likesInBlock = 0
                    updateLikes()
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(bridgeUrl())
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("YouTube LIVE bridge (ws:// or wss://)")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("bridge_url", input.text.toString().trim()).apply()
                bridge.start(bridgeUrl())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun bridgeUrl() = prefs.getString("bridge_url", BuildConfig.DEFAULT_BRIDGE_URL) ?: BuildConfig.DEFAULT_BRIDGE_URL

    private fun setStatus(connected: Boolean) {
        statusText.text = if (connected) "CONNECTED" else "DISCONNECTED"
        statusText.setTextColor(if (connected) 0xFF4CD137.toInt() else 0xFFFF5252.toInt())
    }

    private fun updateLikes() {
        likesText.text = "LIKES $likesInBlock/100"
        prefs.edit().putInt("likes_block", likesInBlock).apply()
    }

    // ---------------------------------------------------------------- LIVE events
    private fun onLive(type: String, count: Int) {
        when (type) {
            "comment" -> engine.addGreen(count.coerceIn(1, 500))            // 1 comment = +1 green apple
            "like" -> {
                val c = count.coerceIn(1, 5000)
                engine.addGreen(5 * c)                                      // 1 like = +5 green apples
                likesInBlock += c
                while (likesInBlock >= 100) {                               // every 100 likes = +50 green apples
                    likesInBlock -= 100
                    engine.addGreen(50)
                }
                updateLikes()
            }
        }
    }

    // ---------------------------------------------------------------- Engine callbacks
    override fun onTurn() = sfx.click()
    override fun onEat(green: Boolean) = sfx.bite()
    override fun onLevelStart(level: Int) {
        levelText.text = "LEVEL $level"
        prefs.edit().putInt("level", level).apply()
    }

    // ---------------------------------------------------------------- Lifecycle
    override fun onResume() {
        super.onResume()
        game.start()
        video.start()
        music?.start()
        bridge.start(bridgeUrl())
    }

    override fun onPause() {
        super.onPause()
        game.stop()
        video.pause()
        music?.pause()
        bridge.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        music?.release()
        sfx.release()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            WindowInsetsControllerCompat(window, window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
}
