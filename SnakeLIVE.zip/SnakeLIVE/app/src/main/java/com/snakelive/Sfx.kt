package com.snakelive

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock

class Sfx(ctx: Context) {
    private val pool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()
    private val clickId = pool.load(ctx, R.raw.click, 1)
    private val biteId = pool.load(ctx, R.raw.bite, 1)
    private var lastClick = 0L
    private var lastBite = 0L

    fun click() {
        val t = SystemClock.uptimeMillis()
        if (t - lastClick < 25) return
        lastClick = t
        pool.play(clickId, 1f, 1f, 1, 0, 1f)
    }

    fun bite() {
        val t = SystemClock.uptimeMillis()
        if (t - lastBite < 40) return
        lastBite = t
        pool.play(biteId, 0.8f, 0.8f, 1, 0, 1f)
    }

    fun release() = pool.release()
}
