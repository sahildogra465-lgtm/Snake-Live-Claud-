package com.snakelive

import kotlin.random.Random

/**
 * Self-playing Snake that cannot die.
 *
 * The snake follows a Hamiltonian cycle that visits every cell of the (even-sized) grid, and only
 * takes shortcuts that provably keep its body in cycle order. Therefore it never hits itself or a
 * wall, and it can keep growing until the whole board is full.
 */
class SnakeEngine(val n: Int = 20, private val listener: Listener) {

    interface Listener {
        fun onTurn()
        fun onEat(green: Boolean)
        fun onLevelStart(level: Int)
    }

    enum class Result { NORMAL, LEVEL_COMPLETE }

    companion object {
        const val MAX_LEVEL = 200
        const val START_APPLES = 100      // red apples on board at level start
        const val MAX_APPLES = 400        // max apples consumable per level
        const val START_LEN = 3
        const val BONUS_EVERY = 10        // every 10 eaten -> +1 apple on board ...
        const val BONUS_UNTIL = 100       // ... until 100 eaten in the level
        private val DX = intArrayOf(1, -1, 0, 0)
        private val DY = intArrayOf(0, 0, 1, -1)
    }

    val cells = n * n
    private val cycleAt = IntArray(cells)   // cycle index -> cell id (id = y*n + x)
    private val idxOf = IntArray(cells)     // cell id -> cycle index

    /** 0 = none, 1 = red (normal), 2 = green (LIVE interaction) */
    val apple = IntArray(cells)
    val body = ArrayDeque<Int>()            // tail first, head last
    private val occupied = BooleanArray(cells)

    var level = 1
        private set
    var lastDir = 0
        private set
    private var eaten = 0
    private var redOnBoard = 0
    private var greenOnBoard = 0
    private var pendingGreen = 0
    private val tmp = IntArray(cells)
    private val rnd = Random.Default

    init {
        require(n % 2 == 0) { "grid size must be even" }
        var i = 0
        for (x in 0 until n) cycleAt[i++] = x
        for (y in 1 until n) {
            if (y % 2 == 1) for (x in n - 1 downTo 1) cycleAt[i++] = y * n + x
            else for (x in 1 until n) cycleAt[i++] = y * n + x
        }
        for (y in n - 1 downTo 1) cycleAt[i++] = y * n
        for (k in 0 until cells) idxOf[cycleAt[k]] = k
    }

    /** Called from the main thread when LIVE events arrive. */
    fun addGreen(count: Int) {
        if (count > 0) pendingGreen += count
    }

    fun startLevel(lvl: Int, clearGreen: Boolean = false) {
        level = lvl.coerceIn(1, MAX_LEVEL)
        if (clearGreen) pendingGreen = 0
        apple.fill(0)
        occupied.fill(false)
        body.clear()
        for (k in 0 until START_LEN) {
            val c = cycleAt[k]
            body.addLast(c)
            occupied[c] = true
        }
        eaten = 0; redOnBoard = 0; greenOnBoard = 0
        lastDir = 0
        fillApples()
        listener.onLevelStart(level)
    }

    /** Move to next level (level 200 simply replays itself). */
    fun advance() = startLevel(if (level < MAX_LEVEL) level + 1 else MAX_LEVEL)

    private fun dist(a: Int, b: Int) = (idxOf[b] - idxOf[a] + cells) % cells

    private fun freeCell(): Int {
        var k = 0
        for (c in 0 until cells) if (!occupied[c] && apple[c] == 0) tmp[k++] = c
        return if (k == 0) -1 else tmp[rnd.nextInt(k)]
    }

    private fun fillApples() {
        val target = START_APPLES + minOf(eaten, BONUS_UNTIL) / BONUS_EVERY
        while (redOnBoard < target && eaten + redOnBoard + greenOnBoard < MAX_APPLES) {
            val c = freeCell(); if (c < 0) break
            apple[c] = 1; redOnBoard++
        }
        while (pendingGreen > 0 && eaten + redOnBoard + greenOnBoard < MAX_APPLES) {
            val c = freeCell(); if (c < 0) break
            apple[c] = 2; greenOnBoard++; pendingGreen--
        }
    }

    fun step(): Result {
        fillApples()
        val head = body.last()
        val tail = body.first()
        val hx = head % n
        val hy = head / n
        var next = cycleAt[(idxOf[head] + 1) % cells]

        // nearest apple along the cycle
        var dT = Int.MAX_VALUE
        for (c in 0 until cells) if (apple[c] != 0) {
            val d = dist(head, c); if (d < dT) dT = d
        }
        if (dT != Int.MAX_VALUE) {
            val td = dist(head, tail)
            val limit = minOf(dT, td - 1)
            var best = 1
            for (k in 0 until 4) {
                val nx = hx + DX[k]; val ny = hy + DY[k]
                if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue
                val nb = ny * n + nx
                if (occupied[nb]) continue
                val d = dist(head, nb)
                if (d in 2..limit && d > best) { best = d; next = nb }
            }
        }

        val dx = next % n - hx
        val dy = next / n - hy
        val dir = when { dx == 1 -> 0; dx == -1 -> 1; dy == 1 -> 2; else -> 3 }
        if (dir != lastDir) listener.onTurn()
        lastDir = dir

        val a = apple[next]
        // No apple: the tail leaves its cell first (the head may legally enter the cell the tail vacates).
        if (a == 0) occupied[body.removeFirst()] = false
        body.addLast(next); occupied[next] = true
        if (a != 0) {
            apple[next] = 0
            if (a == 2) greenOnBoard-- else redOnBoard--
            eaten++            // tail stays -> snake grows by 1
            listener.onEat(a == 2)
        }

        return if (body.size >= cells || eaten >= MAX_APPLES) Result.LEVEL_COMPLETE else Result.NORMAL
    }
}
