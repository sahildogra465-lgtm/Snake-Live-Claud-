plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.snakelive"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.snakelive"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Default bridge address; changeable in-app by tapping the CONNECTED/DISCONNECTED label.
        buildConfigField("String", "DEFAULT_BRIDGE_URL", "\"ws://192.168.1.100:8080\"")
    }
    buildFeatures { buildConfig = true }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
    androidResources { noCompress += listOf("mp4", "m4a", "wav") }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
