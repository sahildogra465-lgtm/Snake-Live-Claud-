# Snake LIVE

Fullscreen portrait Android app (Kotlin, minSdk 24) + a small Node bridge for YouTube LIVE.

## 1. Build the APK
Open this folder in **Android Studio** (Hedgehog or newer), let Gradle sync, then
**Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
Or in a terminal with the Android SDK installed: `gradle assembleDebug`
Result: `app/build/outputs/apk/debug/app-debug.apk` (copy to phone and install).

## 2. YouTube LIVE bridge
YouTube has no push API for likes, so the bridge polls the YouTube Data API v3:
comments come from the live chat, likes from the video's like count (increase = new likes).

1. Google Cloud Console -> create a project -> enable **YouTube Data API v3** -> create an **API key**.
2. `cd bridge && npm install`
3. `YT_API_KEY=your_key YT_VIDEO_ID=your_live_video_id node server.js`
   (Windows PowerShell: `$env:YT_API_KEY="..."; $env:YT_VIDEO_ID="..."; node server.js`)
4. In the app tap the red **DISCONNECTED** label, enter `ws://<PC-IP>:8080` (phone and PC on the same Wi-Fi;
   or host the bridge on a server and use `wss://...`). The label turns green: **CONNECTED**.

Quota: free quota is 10,000 units/day. Chat poll = 5 units, like poll = 1 unit. With the defaults
(chat every 10 s, likes every 5 s) one hour costs about 2,500 units. Raise `CHAT_POLL_MS` / `LIKE_POLL_MS`
for long streams, or request more quota.

## Game rules implemented
* 20x20 board, 100 red apples per level, +1 apple on board for every 10 eaten (until 100 eaten),
  max 400 apples consumed per level, level ends when the board is full. 200 levels (level 200 replays).
* The snake follows a Hamiltonian cycle with safe shortcuts: it cannot die.
* Keyboard click only when the direction changes; soft bite sound on eating.
* Green apples = LIVE events only: comment +1, like +5, every 100 likes +50.
* Music loops at 12% volume. The 3 s clip loops silently inside the MY VIDEO box.

## Hidden controls
* Tap CONNECTED/DISCONNECTED: set bridge address.
* Long-press LEVEL: restart from level 1 (progress is otherwise saved if the app closes).

## Tuning
`GameView.STEP_MS` (speed), `MainActivity` music volume `setVolume(0.12f, 0.12f)`,
snake colours in `GameView`, `DEFAULT_BRIDGE_URL` in `app/build.gradle.kts`.

Keep Snake LIVE in the foreground while screen sharing: it pauses when it goes to the background.

## No Android Studio? Build online (free) with GitHub
1. Create a free account at github.com, then New repository (name: SnakeLIVE).
2. Upload all files of this project (keep the folder structure, including `.github/workflows/build.yml`).
3. Open the **Actions** tab > **Build APK** > **Run workflow**.
4. After ~5 minutes open the finished run and download **SnakeLIVE-apk** (a zip containing app-debug.apk).
